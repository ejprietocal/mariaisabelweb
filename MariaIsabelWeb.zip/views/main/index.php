<?php include_once __DIR__ . '/seccion1.php' ?>
<?php include_once __DIR__ . '/seccion2.php' ?>
<?php include_once __DIR__ . '/seccion3.php' ?>