<div class="seccion7 container-fluid p-0">
    <div class="seccion7-interna container-fluid">
        <h2 class="display-1 fw-bold text-center w-100">Contactanos</h2>
        <p class="fs-3 text-center w-100">¡Estamos aqui para ayudarte!</p>
        <i class="bi bi-arrow-down display-1 d-block text-center mt-5"></i>
        <a href="#" class="boton-comunicate fs-1">Whatsapp</a>
    </div>
</div>