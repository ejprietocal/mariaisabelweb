<div class="seccion1 container-fluid p-0">
    <div class="seccion1-interna p-0">
        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
                <div class="carousel-item active ">
                    <div class="d-flex p-5 align-items-center justify-content-evenly flex-column h-100">
                        <h2 class="display-2 fw-bold text-white text-center">Declaración de renta de año gravable <?php $year = date("Y"); $lastyear = $year - 1; echo $lastyear; ?> </h2>
                        <p class="text-center fs-1 text-white col-12 col-md-6">¿Sabes si estás obligado a presentar declaración de renta por el AG <?php $year = date("Y"); $lastyear = $year - 1; echo $lastyear; ?>?</p>
                        <a href="#" class="boton-asesor fs-3">Contactar Asesor</a>
                    </div>
                </div>
                <!-- <div class="carousel-item">
                    <div class="d-flex p-5 align-items-center justify-content-evenly flex-column h-100">
                        <h2 class="display-2 fw-bold text-white">Titulo 2</h2>
                        <p class="text-center fs-2 text-white w-75">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ut temporibus blanditiis, ab esse alias dicta veniam in suscipit aut aliquid deserunt mollitia. Sit optio culpa excepturi nemo earum perferendis amet?</p>
                        <a href="#" class="boton-asesor fs-3">Contactar Asesor</a>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="d-flex p-5 align-items-center justify-content-evenly flex-column h-100">
                        <h2 class="display-2 fw-bold text-white">Titulo 3</h2>
                        <p class="text-center fs-2 text-white w-75">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ut temporibus blanditiis, ab esse alias dicta veniam in suscipit aut aliquid deserunt mollitia. Sit optio culpa excepturi nemo earum perferendis amet?</p>
                        <a href="#" class="boton-asesor fs-3">Contactar Asesor</a>
                    </div>
                </div> -->
            </div>
            <!-- <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button> -->
        </div>
    </div>
</div>