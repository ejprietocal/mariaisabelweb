<div class="seccion3 container-fluid p-0">
    <div class="seccion3-interna container position-relative">
        <div class="seccion3-frase position-relative z-2">
            <blockquote class="display-2 fw-bold text-white mt-3 mb-3 text-center w-100">
                <p>En un mercado de gran actividad, no destacarse es lo mismo que ser invisible</p>
                <footer class="fs-3">- Seth Godin</footer>
            </blockquote>
            <a href="#" class="boton-comunicate">Comunicate con nosotros</a>
        </div>
        <div class="seccion3-imagen">

        </div>
    </div>
</div>