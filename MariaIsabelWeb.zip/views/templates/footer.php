<div class="footer container-fluid p-0 d-flex aling-items-center justify-content-between flex-column">
    <div class="footer-interno container p-0">
        <picture>
            <source srcset="/build/img/logo.avif" type="image/avif">
            <source srcset="/build/img/logo.webp" type="image/webp">
        
            <img width="100%" src="/build/img/logo.png" alt="logo">
        </picture>    

        <div class="contenedor display-3 d-flex align-items-center justify-content-center gap-5">
            <a href="#"><i class="bi bi-whatsapp"></i></a>
            <a href="#"><i class="bi bi-facebook"></i></a>
            <a href="#"><i class="bi bi-instagram"></i></a>
        </div>
        <div class="contenedor d-flex flex-column justify-content-center p-5">
            <i class="bi bi-quote text-white display-1"></i>
            <p class="text-white fs-3 ps-5 pe-5 m-0 fst-italic">El único modo de hacer un gran trabajo es amar lo que haces.</p>
            <i class="rotada bi bi-quote text-white display-1 me-0 mx-auto d-block"></i>
            <p class="fs-3 text-white fst-italic">- Steve Jobs</p>
        </div>
    </div>

    <div class="container-fluid text-center text-white fs-5">
        <p>Todos los derechos reservados <i class="bi bi-c-circle"></i></p>
        <p>Sitio web desarrollado por <a href="https://pribyte.com">Pribytes</a></p>
    </div>
</div>